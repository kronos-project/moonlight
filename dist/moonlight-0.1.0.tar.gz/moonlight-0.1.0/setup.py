# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['moonlight', 'moonlight.ki']

package_data = \
{'': ['*']}

install_requires = \
['black>=21.12b0,<22.0',
 'overrides>=6.1.0,<7.0.0',
 'printrospector @ git+ssh://git@gitlab.com/vale_/printrospector.git@main',
 'pylint>=2.12.2,<3.0.0',
 'scapy>=2.4.5,<3.0.0']

setup_kwargs = {
    'name': 'moonlight',
    'version': '0.1.0',
    'description': 'Wizard101 MITM agent',
    'long_description': None,
    'author': 'NA',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
